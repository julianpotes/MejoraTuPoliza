$(function() {    

    $('[data-toggle="tooltip"]').tooltip();
    $('.mdb-select').material_select();
    
});